ini adalah dokumentasi Bootstrap 4 offline. Pastikan sudah membaca tutorial cara build-nya di: https://www.petanikode.com/bootstrap4-offline

## Cara Menggunakan

Clone repositori ini ke dalam `htdocs` atau `/var/www/html`.
Ketik perintah berikut:

```bash
cd /var/www/html/
mkdir doc
cd doc
```

Lalu clone repositorinya dengan perintah berikut:

```bash
git clone https://github.com/petanikode/bootstrap4-offline.git bs4
```

Setelah itu buka http://localhost/doc/bs4

:tada: enjoy...
